var prompter = prompt("Hey what is your name?");



var greeting = "Hello my name is " +prompter;

document.querySelector(".words").innerHTML = greeting;
